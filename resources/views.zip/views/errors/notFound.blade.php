@extends('layouts.app')
@section('title', 'view department')
@section('content')

    <div class="container">
        <div class="alert alert-danger">NOT FOUND 404</div>
    </div>
@endsection