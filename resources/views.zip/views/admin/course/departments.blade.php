
@foreach($departments as $department)
    <option>{{$department->en_name}}</option>
@endforeach